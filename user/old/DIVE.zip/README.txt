DIVE (c) paul cho 2018

WORK IN PROGRESS, DEFINITELY NOT THE FINISHED PRODUCT

CONTROLS:
- UP to skip/rest
- LEFT, RIGHT to move sideways/diagonally
- DOWN to move down
- ESC to quit (press twice)
- MOUSE to select items from shop

GAMEPLAY:
- Keep moving to avoid the slowly approaching ice from above
- Press UP while on top of a solid block to restore AIR
--> UP will not restore when a block isn't under the player, but does skip a turn
- You will lose health when running out of air or being within the same space as an ice block
- Pressure increases roughly every 2500ft; the current pressure determines how much air is lost per-move, and is indicated by the red square next to your current air count.
- See how far you can get before your character dies!

NOTES:
** Currently the game is incredibly randomized, so you might be dealt with an awful map. The ideal map contains enough enemies to be tough and provide the player a chance to make money, without being too much to handle at the shallower depths.
** More items will be added to affect gameplay; currently there are only 3
---- HP Refill
---- Goggles (Extend vision vertically by 1 block in each direction)
---- Air Tank (Adds +5 maxiumum capacity to the air tank)


thanks for playing!